﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            MessageBox.Show("Enter Work");
            MessageBox.Show("Enter rows and coloums");
        }

        private void button1_Click(object sender, EventArgs e)
        {




            int row, col,fourTrue;
            bool needLessThanWork=true;
            row = int.Parse(tbxRow.Text);
            col = int.Parse(tbxCol.Text);

            int[,] allocation = new int[row,col];
            int[,] need = new int[row,col] ;
            //
            
            string needArray = tbxNeedEntry.Text;
            string[] strNeedArray = needArray.Split(new Char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            int z = 0;
            foreach (string value in strNeedArray)
            {                            
                    for (int y = 0; y < col; y++)
                    {
                  
                    need[z, y] =int.Parse(value[y].ToString());
                    
                    }
                    z = z + 1;
            }

            //
            //
            string alloArray = tbxAlloEntry.Text;
            string[] strAlloArray = alloArray.Split(new Char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            int x = 0;
            foreach (string value in strAlloArray)
            {
                for (int d = 0; d < col; d++)
                {

                    allocation[x, d] = int.Parse(value[d].ToString());

                }
                x = x + 1;
            }

            //
            //
            string strWorkEntry = tbxWork.Text;
            string[] strWorkArray = strWorkEntry.Split(new Char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            int[] work = new int[col];
            foreach (string value in strWorkArray)
            {
                for (int g = 0; g < col; g++)
                {

                    work[g] = int.Parse(value[g].ToString());

                }
                
            }
            //
            bool[] finished = new bool[row];
            for(int w = 0; w < row; w++)
            {
                finished[w] = false;
            }

            
            string strWork = "";
            string strNeed = "";
            richOutput.Clear();
            string processOutput = "";

            int condition = 0;
            while (condition < 3)
            {


                for (int i = 0; i < row; i++)//change 4 to 5 its the rows
                {

                    if (finished[i] == false)
                    {

                        fourTrue = 0;
                        for (int k = 0; k < col; k++)//going into each one
                        {
                            if (need[i, k] <= work[k])
                            {
                                fourTrue = fourTrue + 1;

                            }


                        }

                        if (fourTrue == col)
                        {
                            newWork(work, ref strWork,col);
                            needOut(need, ref strNeed, i,col);
                            richOutput.AppendText("Need For process: " + i + "  ---> " + strNeed + " is less than equal too " + strWork + "\r\n");
                            for (int n = 0; n < col; n++)
                            {

                                work[n] = work[n] + allocation[i, n];
                                finished[i] = true;


                            }
                            newWork(work, ref strWork,col);
                            richOutput.AppendText("New Work: " + strWork + "\r\n");
                            processOutput = processOutput + "p" + i + ",";

                        }
                        else
                        {
                            needOut(need, ref strNeed, i,col);
                            newWork(work, ref strWork,col);
                            richOutput.AppendText("Need For process: " + i + "  ---> " + strNeed + " is GREATER than  " + strWork + "\r\n");
                        }

                    }




                }
                condition += 1;

            }

            richOutput.AppendText("Processs Order: " + processOutput);

        }

        public void needOut(int[,] need, ref string strneed,int position,int col)
        {
            strneed = "";
            for (int r = 0; r < col; r++)
            {
                strneed = strneed + " " + need[position,r];
            }
        }

        public void newWork(int [] wrk,ref string strwrk, int col)
        {
            strwrk = "";
            for (int r = 0; r < col; r++)
            {
                strwrk = strwrk+" "+ wrk[r];
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            
        }
    }
}
